#include <stdio.h>

int Func(int n)
{

}

int main()
{
    return 0;
}